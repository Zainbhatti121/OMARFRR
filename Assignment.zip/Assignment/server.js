const express = require('express')
const mysql = require('mysql')
const PORT = 300;
const path = require('path')

const app = express();

app.use(express.json());
// app.set('view engine','html')
app.use(express.static(__dirname + '/static'))
app.use(express.urlencoded());

const db = mysql.createConnection({host:"localhost",user:"root",password:"admin",multipleStatements: true,insecureAuth:true});
db.connect((err)=>{
    if(err){
        console.log("error!")
        throw err;
    }

    console.log("Connected to the db!")
})

app.get('/init',(req,res)=>{

    const query = "CREATE DATABASE IF NOT EXISTS postdb;USE postdb;CREATE TABLE IF NOT EXISTS posts (id int NOT NULL AUTO_INCREMENT,name TEXT, description TEXT,PRIMARY KEY (id));"
    db.query(query,[1,2],(err)=>{
        if(err){

            res.status(400).send(err)
            throw err;
        }

        res.status(200).send("postdb database created with posts table!")
    
    })
})

app.get('/getPosts',(req,res)=>{
    const query = "USE postdb;SELECT * FROM posts"
    db.query(query,[1,2],(err,data)=>{
        if(err){
            throw err;
        }
          
        res.status(200).send(data[1])

    
    })
})


app.get('/addPost',(req,res)=>{
     res.status(200).sendFile(path.join(__dirname + "/views/posting.html"))
})

app.post('/addPost',(req,res)=>{
    const query = `USE postdb;INSERT INTO posts (name,description) VALUES("${req.body.name}","${req.body.description}");`
    db.query(query,[1,2],(err,data)=>{
        if(err){
            throw err;
        }
          
        res.status(200).send("Post Added to the database!")

    
    })
})

app.listen(PORT,()=>{
    console.log(`server started on port ${PORT}`)
})